# Arcaia Model Decoration Watch Probe v1.0.1

モデルセレクターのArcaia装飾が、再現手順不明のまま外れる問題を待ち受ける独立Chrome拡張です。通常版Arcaiaと同時に有効化します。

## 動作

- ページ上にはマークや常駐UIを表示しません。
- 一度正常に装飾された同じモデルボタンを基準として記録します。
- 同じボタンから装飾属性、装飾DOM、装飾styleが消えた場合に異常として記録します。
- ボタン自体が交換された場合は1.2秒だけArcaiaの再適用を待ち、GPT-5.6候補へ装飾が戻らない場合に記録します。
- Arcaia本体の`page_navigation`イベントを利用し、会話から新規チャットなどのSPA遷移後に装飾が戻らないケースも記録します。
- SPA遷移先で同じ性能表示の候補が残り、明示的な別モデル表示がない場合は`route_transition_not_redecorated`として記録します。
- GPT-5.5など別モデルへの明示変更は異常扱いしません。
- 異常時だけChromeツールバーのprobeアイコンへ赤い`!`バッジを表示します。
- probeアイコンをクリックすると、`MODEL DECORATION LOST`、検出理由、時刻、診断状態を確認できます。
- popupから診断JSONを保存できます。
- 目視では再現したのに自動検出されない場合は、popupの「現在を記録」を押します。

## 監視範囲

通常時のMutationObserverは次に限定します。

- `form[data-type="unified-composer"]`
- Composerの直近親とその親
- 現在の装飾済みモデルボタン
- `head`直下のArcaiaモデル装飾style

Composerがまだ存在しない場合だけ、最大30秒の一時bootstrap Observerを使用します。`setInterval`、常時ポーリング、ページ本文全体の永続Observerは使用しません。

## 導入

1. ZIPを展開します。
2. `chrome://extensions/`を開きます。
3. デベロッパーモードを有効にします。
4. 「パッケージ化されていない拡張機能を読み込む」から展開フォルダを選択します。
5. 通常版Arcaiaも有効のままにします。
6. ChatGPTページをハードリロードします。
7. probeアイコンをChromeツールバーへ固定して、そのまま再現を待ちます。

## 異常を検出したら

1. ChatGPTページをリロードせず、probeアイコンをクリックします。
2. `JSON保存`を押します。
3. 出力されたJSONを添付します。
4. 赤い`!`だけ消す場合は「マーク解除」を使います。記録は残ります。
5. 新しい監視セッションへ切り替える場合だけ「記録をリセット」を使います。

## Privacy

収集しません。

- 会話本文
- conversation ID実値
- URL全文
- Cookie
- Authorization
- ChatGPT Storage値
- Arcaia Storage値
- HTML全文

外部拡張のisolated worldからは、Arcaia Content Script内部変数、Arcaiaの`chrome.storage.local`、Arcaia内部例外を直接取得できません。DOM上の装飾状態と局所的な交換時系列から原因候補を絞るprobeです。
