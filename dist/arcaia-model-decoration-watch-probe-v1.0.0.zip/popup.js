(() => {
  'use strict';

  const SOURCE = 'arcaia-model-decoration-watch-v1';
  const REPORT_KEY = 'arcaiaModelDecorationWatchReportV1';
  const elements = {
    statusCard: document.getElementById('status-card'),
    statusTitle: document.getElementById('status-title'),
    statusDetail: document.getElementById('status-detail'),
    baseline: document.getElementById('baseline'),
    incidentCount: document.getElementById('incident-count'),
    lastIncident: document.getElementById('last-incident'),
    updatedAt: document.getElementById('updated-at'),
    capture: document.getElementById('capture'),
    download: document.getElementById('download'),
    ack: document.getElementById('ack'),
    reset: document.getElementById('reset')
  };
  let activeTabId = null;
  let currentTabReport = null;

  function formatTime(iso) {
    if (!iso) return '未取得';
    const date = new Date(iso);
    if (!Number.isFinite(date.getTime())) return '未取得';
    return date.toLocaleString('ja-JP');
  }

  function statusCopy(status) {
    if (status === 'lost') return ['再現検出', 'MODEL DECORATION LOST'];
    if (status === 'recovered_marked') return ['復旧済み・マーク保持', '検出時の記録を保存できます'];
    if (status === 'acknowledged') return ['確認済み', '記録は保持されています'];
    if (status === 'watching') return ['監視中', '異常時だけツールバーへ「!」を表示します'];
    return ['未接続', '対象ChatGPTタブでprobeが起動していません'];
  }

  function render(tabReport) {
    currentTabReport = tabReport || null;
    const status = tabReport?.status || 'waiting';
    const [title, detail] = statusCopy(status);
    elements.statusCard.dataset.state = status;
    elements.statusTitle.textContent = title;
    elements.statusDetail.textContent = detail;
    elements.baseline.textContent = tabReport?.baseline
      ? `${tabReport.baseline.modelVersion || 'GPT-5.6'}${tabReport.baseline.performance ? ` / ${tabReport.baseline.performance}` : ''}`
      : '未取得';
    elements.incidentCount.textContent = String(tabReport?.incidentCount || 0);
    elements.lastIncident.textContent = tabReport?.lastIncident
      ? `${tabReport.lastIncident.kind} / ${formatTime(tabReport.lastIncident.detectedAtIso)}`
      : 'なし';
    elements.updatedAt.textContent = formatTime(tabReport?.updatedAtIso);
    elements.download.disabled = !tabReport;
    elements.ack.disabled = !tabReport?.marked;
  }

  async function getActiveTab() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    return tabs[0] || null;
  }

  async function load() {
    const tab = await getActiveTab();
    activeTabId = Number.isInteger(tab?.id) ? tab.id : null;
    if (!Number.isInteger(activeTabId)) {
      render(null);
      return;
    }
    const data = await chrome.storage.local.get(REPORT_KEY);
    render(data?.[REPORT_KEY]?.tabs?.[String(activeTabId)] || null);
  }

  async function sendToActiveTab(type) {
    if (!Number.isInteger(activeTabId)) return null;
    try {
      return await chrome.tabs.sendMessage(activeTabId, { source: SOURCE, type });
    } catch {
      return null;
    }
  }

  function downloadReport() {
    if (!currentTabReport) return;
    const exportPayload = {
      probe: {
        name: 'Arcaia Model Decoration Watch Probe',
        version: '1.0.0',
        generatedAtIso: new Date().toISOString()
      },
      privacy: {
        conversationTextCollected: false,
        conversationIdsCollected: false,
        urlsCollected: false,
        cookiesCollected: false,
        authorizationCollected: false,
        pageStorageValuesCollected: false,
        htmlCollected: false,
        otherExtensionStorageCollected: false
      },
      limitations: {
        arcaiaIsolatedWorldVariablesVisible: false,
        arcaiaExtensionStorageVisible: false,
        arcaiaContentScriptExceptionsVisible: false
      },
      tabReport: currentTabReport
    };
    const blob = new Blob([`${JSON.stringify(exportPayload, null, 2)}\n`], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `arcaia-model-decoration-watch-${Date.now()}.json`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 0);
  }

  async function acknowledge() {
    if (!Number.isInteger(activeTabId)) return;
    await chrome.runtime.sendMessage({ source: SOURCE, type: 'ACK_TAB', tabId: activeTabId });
    await load();
  }

  async function reset() {
    if (!Number.isInteger(activeTabId)) return;
    await chrome.runtime.sendMessage({ source: SOURCE, type: 'RESET_TAB', tabId: activeTabId });
    await sendToActiveTab('RESET_PROBE_SESSION');
    await load();
  }

  elements.capture.addEventListener('click', async () => {
    await sendToActiveTab('CAPTURE_NOW');
    await load();
  });
  elements.download.addEventListener('click', downloadReport);
  elements.ack.addEventListener('click', () => { void acknowledge(); });
  elements.reset.addEventListener('click', () => { void reset(); });
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'local' || !changes[REPORT_KEY]) return;
    const report = changes[REPORT_KEY].newValue;
    render(report?.tabs?.[String(activeTabId)] || null);
  });
  void load();
})();
