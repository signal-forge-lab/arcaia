(() => {
  'use strict';

  const SOURCE = 'arcaia-model-decoration-watch-v1';
  const PROBE_NAME = 'Arcaia Model Decoration Watch Probe';
  const PROBE_VERSION = '1.0.0';
  const COMPOSER_SELECTOR = 'form[data-type="unified-composer"]';
  const RICH_TRIGGER_SELECTOR = 'button[data-arcaia-model-rich="true"]';
  const RICH_CONTENT_SELECTOR = '[data-arcaia-model-rich-content="true"]';
  const MODEL_STYLE_SELECTOR = '#arcaia-model-selector-rich-style';
  const NATIVE_LABEL_SELECTOR = '[data-arcaia-model-native-label="true"]';
  const BOOTSTRAP_DURATION_MS = 30000;
  const REPLACEMENT_GRACE_MS = 1200;
  const MODEL_PATTERN = /\bGPT[-\u2011\u2013\s]?(\d+(?:\.\d+)?)\b/i;
  const PERFORMANCE_LABELS = new Set([
    '軽', '最速', '中程度', '高い', '非常に高い', '最大',
    'Light', 'Fastest', 'Medium', 'High', 'Very high', 'Maximum'
  ]);

  let sessionId = createSessionId();
  let eventSequence = 0;
  let routeGeneration = 1;
  let lastPathname = String(location.pathname || '');
  let baseline = null;
  let incidentActive = false;
  let triggerSequence = 0;
  let observedComposer = null;
  let observedComposerParent = null;
  let observedComposerGrandparent = null;
  let observedTrigger = null;
  let composerObserver = null;
  let composerParentObserver = null;
  let composerGrandparentObserver = null;
  let triggerObserver = null;
  let headObserver = null;
  let bootstrapObserver = null;
  let bootstrapTimer = null;
  let replacementTimer = null;
  let replacementToken = 0;
  let evaluationQueued = false;

  function createSessionId() {
    return `model-watch-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  }

  function normalizeText(value) {
    return String(value || '').replace(/\s+/g, ' ').trim();
  }

  function classifyRoute() {
    const pathname = String(location.pathname || '');
    if (/^\/c\/[^/]+/i.test(pathname)) return 'conversation';
    if (pathname === '/' || pathname === '') return 'new_chat';
    if (/^\/(?:g|gg)\/[^/]+/i.test(pathname)) return 'gpt_surface';
    return 'other';
  }

  function updateRouteGeneration() {
    const pathname = String(location.pathname || '');
    if (pathname === lastPathname) return false;
    lastPathname = pathname;
    routeGeneration += 1;
    return true;
  }

  function extractExplicitModelVersion(element) {
    if (!(element instanceof Element)) return null;
    const values = [
      element.textContent,
      element.getAttribute('aria-label'),
      element.getAttribute('title')
    ];
    for (const value of values) {
      const match = normalizeText(value).match(MODEL_PATTERN);
      if (match?.[1]) return `GPT-${match[1]}`;
    }
    return null;
  }

  function findKnownPerformanceLabel(element) {
    if (!(element instanceof Element)) return null;
    const values = [
      normalizeText(element.textContent),
      normalizeText(element.getAttribute('aria-label')),
      normalizeText(element.getAttribute('title'))
    ];
    for (const value of values) {
      for (const label of PERFORMANCE_LABELS) {
        if (value === label || value.startsWith(`${label} `) || value.endsWith(` ${label}`)) return label;
      }
    }
    return null;
  }

  function sanitizeModelVersion(value) {
    const match = normalizeText(value).match(MODEL_PATTERN);
    return match?.[1] ? `GPT-${match[1]}` : null;
  }

  function sanitizePerformance(value) {
    const normalized = normalizeText(value);
    return PERFORMANCE_LABELS.has(normalized) ? normalized : null;
  }

  function isPickerOpen(trigger) {
    return trigger?.getAttribute?.('aria-expanded') === 'true'
      || trigger?.getAttribute?.('data-state') === 'open';
  }

  function describeTrigger(trigger) {
    if (!(trigger instanceof HTMLButtonElement)) return null;
    return {
      connected: Boolean(trigger.isConnected),
      inComposer: Boolean(trigger.closest?.(COMPOSER_SELECTOR)),
      richApplied: trigger.getAttribute('data-arcaia-model-rich') === 'true',
      richContentPresent: Boolean(trigger.querySelector(RICH_CONTENT_SELECTOR)),
      nativeLabelMarked: Boolean(trigger.querySelector(NATIVE_LABEL_SELECTOR)),
      modelVersion: sanitizeModelVersion(trigger.getAttribute('data-arcaia-model-version')),
      performance: sanitizePerformance(trigger.getAttribute('data-arcaia-model-performance')),
      explicitModelVersion: extractExplicitModelVersion(trigger),
      knownPerformanceLabel: findKnownPerformanceLabel(trigger),
      pickerOpen: isPickerOpen(trigger),
      stylePresent: Boolean(document.querySelector(MODEL_STYLE_SELECTOR)),
      childElementCount: trigger.children?.length || 0,
      richContentChildCount: trigger.querySelector(RICH_CONTENT_SELECTOR)?.children?.length || 0
    };
  }

  function findPotentialTriggers(composer = observedComposer) {
    if (!(composer instanceof Element)) return [];
    return Array.from(composer.querySelectorAll('button[aria-haspopup="menu"]')).filter((button) => (
      button.matches(RICH_TRIGGER_SELECTOR)
      || Boolean(extractExplicitModelVersion(button))
      || Boolean(findKnownPerformanceLabel(button))
      || /model|thinking|intelligence/i.test(String(button.getAttribute('data-testid') || ''))
    ));
  }

  function findDecoratedTrigger(composer = observedComposer) {
    return composer?.querySelector?.(RICH_TRIGGER_SELECTOR) || null;
  }

  function findPotentialTrigger(composer = observedComposer) {
    const candidates = findPotentialTriggers(composer);
    return candidates.find((button) => button.matches(RICH_TRIGGER_SELECTOR))
      || candidates.find((button) => Boolean(extractExplicitModelVersion(button)))
      || candidates.find((button) => Boolean(findKnownPerformanceLabel(button)))
      || candidates[0]
      || null;
  }

  function baselineSummary() {
    if (!baseline) return null;
    return {
      triggerSequence: baseline.triggerSequence,
      routeGeneration: baseline.routeGeneration,
      modelVersion: baseline.modelVersion,
      performance: baseline.performance,
      armedAtIso: baseline.armedAtIso,
      triggerConnected: Boolean(baseline.trigger?.isConnected)
    };
  }

  function buildSnapshot(reason) {
    const composer = document.querySelector(COMPOSER_SELECTOR);
    const decorated = findDecoratedTrigger(composer);
    const candidate = decorated || findPotentialTrigger(composer);
    return {
      reason,
      capturedAtIso: new Date().toISOString(),
      readyState: document.readyState,
      routeKind: classifyRoute(),
      routeGeneration,
      documentVisible: document.visibilityState === 'visible',
      composerPresent: Boolean(composer),
      composerConnected: Boolean(composer?.isConnected),
      potentialTriggerCount: findPotentialTriggers(composer).length,
      decoratedTriggerCount: composer?.querySelectorAll?.(RICH_TRIGGER_SELECTOR).length || 0,
      stylePresent: Boolean(document.querySelector(MODEL_STYLE_SELECTOR)),
      baseline: baselineSummary(),
      incidentActive,
      candidate: describeTrigger(candidate),
      observers: {
        composerBound: Boolean(observedComposer?.isConnected && composerObserver),
        triggerBound: Boolean(observedTrigger?.isConnected && triggerObserver),
        headBound: Boolean(headObserver),
        bootstrapActive: Boolean(bootstrapObserver)
      }
    };
  }

  function emit(type, details = {}) {
    const event = {
      sessionId,
      sequence: ++eventSequence,
      type,
      atIso: new Date().toISOString(),
      routeKind: classifyRoute(),
      routeGeneration,
      ...details
    };
    try {
      chrome.runtime.sendMessage({ source: SOURCE, type: 'PROBE_EVENT', event });
    } catch {}
    return event;
  }

  function disconnectObserver(observer) {
    try { observer?.disconnect?.(); } catch {}
  }

  function stopBootstrap() {
    disconnectObserver(bootstrapObserver);
    bootstrapObserver = null;
    if (bootstrapTimer) clearTimeout(bootstrapTimer);
    bootstrapTimer = null;
  }

  function nodeContainsComposer(node) {
    if (!(node instanceof Element)) return false;
    return node.matches(COMPOSER_SELECTOR) || Boolean(node.querySelector?.(COMPOSER_SELECTOR));
  }

  function startBootstrap(reason = 'composer_missing') {
    if (bootstrapObserver || document.querySelector(COMPOSER_SELECTOR)) return;
    const target = document.documentElement;
    if (!target) return;
    bootstrapObserver = new MutationObserver((mutations) => {
      const composerAdded = mutations.some((mutation) => (
        Array.from(mutation.addedNodes || []).some(nodeContainsComposer)
      ));
      if (!composerAdded && !document.querySelector(COMPOSER_SELECTOR)) return;
      stopBootstrap();
      queueEvaluate('bootstrap_composer_added');
    });
    bootstrapObserver.observe(target, { childList: true, subtree: true });
    bootstrapTimer = setTimeout(() => {
      stopBootstrap();
      emit('bootstrap_timeout', { reason, snapshot: buildSnapshot('bootstrap_timeout') });
    }, BOOTSTRAP_DURATION_MS);
  }

  function bindHeadObserver() {
    if (headObserver || !document.head) return;
    headObserver = new MutationObserver((mutations) => {
      const styleChanged = mutations.some((mutation) => {
        const nodes = [...Array.from(mutation.addedNodes || []), ...Array.from(mutation.removedNodes || [])];
        return nodes.some((node) => (
          node instanceof Element
          && (node.id === MODEL_STYLE_SELECTOR.slice(1) || Boolean(node.querySelector?.(MODEL_STYLE_SELECTOR)))
        ));
      });
      if (styleChanged) queueEvaluate('model_style_mutation');
    });
    headObserver.observe(document.head, { childList: true });
  }

  function nodeContainsModelSignal(node) {
    if (!(node instanceof Element)) return false;
    if (node.matches('button[aria-haspopup="menu"], [data-arcaia-model-rich-content="true"]')) return true;
    return Boolean(node.querySelector?.('button[aria-haspopup="menu"], [data-arcaia-model-rich-content="true"]'));
  }

  function handleComposerMutations(mutations) {
    const relevant = mutations.some((mutation) => {
      if (mutation.type === 'attributes') {
        const button = mutation.target instanceof Element
          ? mutation.target.closest?.('button[aria-haspopup="menu"]')
          : null;
        return Boolean(button?.closest?.(COMPOSER_SELECTOR));
      }
      return [...Array.from(mutation.addedNodes || []), ...Array.from(mutation.removedNodes || [])]
        .some(nodeContainsModelSignal);
    });
    if (relevant) queueEvaluate('composer_model_mutation');
  }

  function handleComposerContainerMutation(reason) {
    if (!observedComposer?.isConnected || document.querySelector(COMPOSER_SELECTOR) !== observedComposer) {
      queueEvaluate(reason);
    }
  }

  function bindComposer() {
    const composer = document.querySelector(COMPOSER_SELECTOR);
    const parent = composer?.parentElement || null;
    const grandparent = parent?.parentElement || null;
    if (
      composer === observedComposer
      && parent === observedComposerParent
      && grandparent === observedComposerGrandparent
      && composerObserver
    ) {
      return composer;
    }

    disconnectObserver(composerObserver);
    disconnectObserver(composerParentObserver);
    disconnectObserver(composerGrandparentObserver);
    composerObserver = null;
    composerParentObserver = null;
    composerGrandparentObserver = null;
    observedComposer = composer;
    observedComposerParent = parent;
    observedComposerGrandparent = grandparent;

    if (!composer) {
      startBootstrap('bind_composer_missing');
      return null;
    }

    stopBootstrap();
    composerObserver = new MutationObserver(handleComposerMutations);
    composerObserver.observe(composer, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: [
        'aria-expanded',
        'data-state',
        'data-arcaia-model-rich',
        'data-arcaia-model-version',
        'data-arcaia-model-performance'
      ]
    });
    if (parent) {
      composerParentObserver = new MutationObserver(() => handleComposerContainerMutation('composer_parent_mutation'));
      composerParentObserver.observe(parent, { childList: true });
    }
    if (grandparent) {
      composerGrandparentObserver = new MutationObserver(() => handleComposerContainerMutation('composer_grandparent_mutation'));
      composerGrandparentObserver.observe(grandparent, { childList: true });
    }
    emit('composer_bound', { snapshot: buildSnapshot('composer_bound') });
    return composer;
  }

  function bindTriggerObserver(trigger) {
    const next = trigger instanceof HTMLButtonElement ? trigger : null;
    if (next === observedTrigger && triggerObserver) return;
    disconnectObserver(triggerObserver);
    triggerObserver = null;
    observedTrigger = next;
    if (!next) return;
    triggerObserver = new MutationObserver(() => queueEvaluate('baseline_trigger_mutation'));
    triggerObserver.observe(next, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: [
        'aria-expanded',
        'data-state',
        'data-arcaia-model-rich',
        'data-arcaia-model-version',
        'data-arcaia-model-performance'
      ]
    });
  }

  function cancelReplacementGrace() {
    replacementToken += 1;
    if (replacementTimer) clearTimeout(replacementTimer);
    replacementTimer = null;
  }

  function armBaseline(trigger, reason) {
    const description = describeTrigger(trigger);
    if (!description?.richApplied || !description.richContentPresent || !description.stylePresent) return false;
    const isSameBaseline = baseline?.trigger === trigger
      && baseline.modelVersion === description.modelVersion
      && baseline.performance === description.performance;
    if (isSameBaseline) {
      bindTriggerObserver(trigger);
      return true;
    }
    triggerSequence += 1;
    baseline = {
      trigger,
      triggerSequence,
      routeGeneration,
      modelVersion: description.modelVersion || 'GPT-5.6',
      performance: description.performance,
      armedAtIso: new Date().toISOString()
    };
    bindTriggerObserver(trigger);
    cancelReplacementGrace();
    const type = triggerSequence === 1 ? 'baseline_armed' : 'baseline_rearmed';
    emit(type, {
      reason,
      baseline: baselineSummary(),
      snapshot: buildSnapshot(type)
    });
    if (incidentActive) {
      incidentActive = false;
      emit('recovered', {
        reason,
        baseline: baselineSummary(),
        snapshot: buildSnapshot('recovered')
      });
    }
    return true;
  }

  function disarmForModelChange(trigger, reason) {
    const explicitModelVersion = extractExplicitModelVersion(trigger);
    if (!explicitModelVersion || explicitModelVersion === baseline?.modelVersion) return false;
    emit('explicit_model_change', {
      reason,
      fromModelVersion: baseline?.modelVersion || null,
      toModelVersion: explicitModelVersion,
      snapshot: buildSnapshot('explicit_model_change')
    });
    baseline = null;
    incidentActive = false;
    bindTriggerObserver(null);
    cancelReplacementGrace();
    return true;
  }

  function markIncident(kind, reason, trigger = null) {
    if (incidentActive) return;
    incidentActive = true;
    const incident = {
      kind,
      reason,
      detectedAtIso: new Date().toISOString(),
      routeKind: classifyRoute(),
      routeGeneration,
      baseline: baselineSummary(),
      observed: describeTrigger(trigger)
    };
    emit('incident', {
      reason,
      incident,
      snapshot: buildSnapshot(`incident:${kind}`)
    });
  }

  function candidateLooksExpected(candidate) {
    if (!(candidate instanceof HTMLButtonElement) || !baseline) return false;
    const explicit = extractExplicitModelVersion(candidate);
    if (explicit) return explicit === baseline.modelVersion;
    const performance = findKnownPerformanceLabel(candidate);
    if (!performance) return false;
    if (baseline.routeGeneration !== routeGeneration) return false;
    return !baseline.performance || performance === baseline.performance || PERFORMANCE_LABELS.has(performance);
  }

  function scheduleReplacementGrace(reason, candidate) {
    if (replacementTimer) return;
    const token = ++replacementToken;
    emit('replacement_grace_started', {
      reason,
      candidate: describeTrigger(candidate),
      snapshot: buildSnapshot('replacement_grace_started')
    });
    replacementTimer = setTimeout(() => {
      replacementTimer = null;
      if (token !== replacementToken || !baseline) return;
      bindComposer();
      const decorated = findDecoratedTrigger();
      if (decorated && armBaseline(decorated, 'replacement_grace_recovered')) return;
      const nextCandidate = findPotentialTrigger();
      if (disarmForModelChange(nextCandidate, 'replacement_grace_model_change')) return;
      if (candidateLooksExpected(nextCandidate)) {
        markIncident('replacement_trigger_not_redecorated', reason, nextCandidate);
      } else {
        emit('replacement_grace_inconclusive', {
          reason,
          candidate: describeTrigger(nextCandidate),
          snapshot: buildSnapshot('replacement_grace_inconclusive')
        });
      }
    }, REPLACEMENT_GRACE_MS);
  }

  function evaluate(reason = 'evaluate') {
    evaluationQueued = false;
    const routeChanged = updateRouteGeneration();
    bindHeadObserver();
    const composer = bindComposer();
    if (!composer) return buildSnapshot(reason);

    const decorated = findDecoratedTrigger(composer);
    if (decorated && armBaseline(decorated, reason)) return buildSnapshot(reason);
    if (!baseline) return buildSnapshot(reason);

    const baselineTrigger = baseline.trigger;
    if (baselineTrigger?.isConnected && baselineTrigger.closest?.(COMPOSER_SELECTOR) === composer) {
      if (disarmForModelChange(baselineTrigger, `${reason}:same_trigger_model_change`)) return buildSnapshot(reason);
      const description = describeTrigger(baselineTrigger);
      if (description?.pickerOpen) {
        scheduleReplacementGrace(`${reason}:picker_open`, baselineTrigger);
        return buildSnapshot(reason);
      }
      if (!description?.stylePresent) {
        markIncident('model_style_removed', reason, baselineTrigger);
      } else if (!description?.richApplied) {
        markIncident('same_trigger_rich_attribute_removed', reason, baselineTrigger);
      } else if (!description?.richContentPresent) {
        markIncident('same_trigger_rich_content_removed', reason, baselineTrigger);
      }
      return buildSnapshot(reason);
    }

    bindTriggerObserver(null);
    const candidate = findPotentialTrigger(composer);
    if (disarmForModelChange(candidate, `${reason}:replacement_model_change`)) return buildSnapshot(reason);
    if (candidateLooksExpected(candidate)) {
      scheduleReplacementGrace(routeChanged ? `${reason}:route_changed` : reason, candidate);
    } else if (!bootstrapObserver) {
      emit('replacement_waiting_for_candidate', {
        reason,
        routeChanged,
        candidate: describeTrigger(candidate),
        snapshot: buildSnapshot('replacement_waiting_for_candidate')
      });
    }
    return buildSnapshot(reason);
  }

  function queueEvaluate(reason = 'queued') {
    if (evaluationQueued) return;
    evaluationQueued = true;
    const run = () => evaluate(reason);
    if (typeof requestAnimationFrame === 'function') requestAnimationFrame(run);
    else setTimeout(run, 0);
  }

  function manualSnapshot(reason = 'toolbar_manual_capture') {
    const snapshot = evaluate(reason);
    emit('manual_snapshot', { reason, snapshot });
    return snapshot;
  }

  function resetProbeSession() {
    sessionId = createSessionId();
    eventSequence = 0;
    baseline = null;
    incidentActive = false;
    triggerSequence = 0;
    bindTriggerObserver(null);
    cancelReplacementGrace();
    emit('probe_reset', { snapshot: buildSnapshot('probe_reset') });
    queueEvaluate('probe_reset_rearm');
  }

  function handleDocumentClick(event) {
    const target = event.target instanceof Element ? event.target : null;
    if (!target) return;
    const modelButton = target.closest?.('button[aria-haspopup="menu"]');
    const surfaceButton = target.closest?.('button[role="radio"]');
    const navigationLink = target.closest?.('a[href]');
    if (modelButton?.closest?.(COMPOSER_SELECTOR) || surfaceButton || navigationLink) {
      queueEvaluate('relevant_document_click');
    }
  }

  function handleVisibilityChange() {
    if (document.visibilityState === 'visible') queueEvaluate('document_visible');
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message || message.source !== SOURCE) return false;
    if (message.type === 'CAPTURE_NOW') {
      sendResponse({ ok: true, snapshot: manualSnapshot() });
      return false;
    }
    if (message.type === 'RESET_PROBE_SESSION') {
      resetProbeSession();
      sendResponse({ ok: true });
      return false;
    }
    if (message.type === 'GET_LIVE_STATUS') {
      sendResponse({ ok: true, snapshot: buildSnapshot('get_live_status') });
      return false;
    }
    return false;
  });

  document.addEventListener('click', handleDocumentClick, true);
  document.addEventListener('visibilitychange', handleVisibilityChange);
  window.addEventListener('focus', () => queueEvaluate('window_focus'));
  window.addEventListener('pageshow', () => queueEvaluate('pageshow'));
  window.addEventListener('popstate', () => queueEvaluate('popstate'));
  window.addEventListener('hashchange', () => queueEvaluate('hashchange'));
  document.addEventListener('DOMContentLoaded', () => queueEvaluate('DOMContentLoaded'), { once: true });
  window.addEventListener('load', () => queueEvaluate('window_load'), { once: true });

  emit('probe_started', {
    probe: { name: PROBE_NAME, version: PROBE_VERSION },
    privacy: {
      conversationTextCollected: false,
      conversationIdsCollected: false,
      urlsCollected: false,
      cookiesCollected: false,
      authorizationCollected: false,
      pageStorageValuesCollected: false,
      htmlCollected: false,
      otherExtensionStorageCollected: false
    },
    snapshot: buildSnapshot('document_start')
  });
  queueEvaluate('startup');
})();
